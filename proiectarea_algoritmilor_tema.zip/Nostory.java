/*
 * Acest schelet citește datele de intrare și scrie răspunsul generat de voi,
 * astfel că e suficient să completați cele două metode.
 *
 * Scheletul este doar un punct de plecare, îl puteți modifica oricum doriți.
 *
 * Dacă păstrați scheletul, nu uitați să redenumiți clasa și fișierul.
 */
import java.util.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.io.Reader;
public class Nostory {
	public static void main(final String[] args) throws IOException {
		var scanner = new MyScanner(new FileReader("nostory.in"));

		var task = scanner.nextInt();
		var n = scanner.nextInt();
		var moves = task == 2 ? scanner.nextInt() : 0;

		var a = new int[n];
		for (var i = 0; i < n; i += 1) {
			a[i] = scanner.nextInt();
		}

		var b = new int[n];
		for (var i = 0; i < n; i += 1) {
			b[i] = scanner.nextInt();
		}

		try (var printer = new PrintStream("nostory.out")) {
			if (task == 1) {
				printer.println(solveTask1(a, b));
			} else {
				printer.println(solveTask2(a, b, moves));
			}
		}
	}

	private static long solveTask1(int[] a, int[] b) {
		int []vect=new int[a.length+b.length];
		long s=0;
		for(int i=0;i<a.length;i++)
		{
            vect[i]=a[i];
		}
		for(int i=0;i<b.length;i++)
		{
			vect[a.length+i]=b[i];
		}
		for(int i=0;i<vect.length-1;i++)
		{
			for(int j=i+1;j<vect.length;j++)
			{
				if(vect[i]<vect[j])
				{
					int aux=vect[j];
					vect[j]=vect[i];
					vect[i]=aux;
				}
			}
		}
		int n=a.length;
		int k=0;
		while(n!=0)
		{
			s=s+vect[k];
			k++;
			n--;
		}
		return s;
	}

	private static long solveTask2(int[] a, int[] b, int moves) {
		int[] min=new int[a.length];
		int[] max=new int[a.length];
		for(int i=0;i<a.length;i++)
		{
			if (a[i]>b[i])
			{
				min[i]=b[i];
				max[i]=a[i];
			}
			else
			{
				min[i]=a[i];
				max[i]=b[i];
			}
		}
		for(int i=0;i<min.length-1;i++)
		{for(int j=i+1;j<min.length;j++)
			 {
				  if(min[i]<min[j])
				  {
					  int aux=min[j];
					  min[j]=min[i];
					  min[i]=aux;
				  }
				  if(max[i]>max[j])
				  {
					  int aux1=max[j];
					  max[j]=max[i];
					  max[i]=aux1;
				  }
			 }
			}
		for(int i=0;i<min.length;i++)
		{if(moves == 0)
		  break;
		if(min[i]>max[i])
		{
			int aux=min[i];
			min[i]=max[i];
			max[i]=aux;
			moves--;
		}
		 }
		int n=a.length;
		int k=0;
		long s=0;
		while(n!=0)
		{
			s=s+max[k];
			k++;
			n--;
		}
		return s;

	}

	/**
	 * A class for buffering read operations, inspired from here:
	 * https://pastebin.com/XGUjEyMN.
	 */
	private static class MyScanner {
		private BufferedReader br;
		private StringTokenizer st;

		public MyScanner(Reader reader) {
			br = new BufferedReader(reader);
		}

		public String next() {
			while (st == null || !st.hasMoreElements()) {
				try {
					st = new StringTokenizer(br.readLine());
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			return st.nextToken();
		}

		public int nextInt() {
			return Integer.parseInt(next());
		}

		public long nextLong() {
			return Long.parseLong(next());
		}

		public double nextDouble() {
			return Double.parseDouble(next());
		}

		public String nextLine() {
			String str = "";
			try {
				str = br.readLine();
			} catch (IOException e) {
				e.printStackTrace();
			}
			return str;
		}
	}
}
