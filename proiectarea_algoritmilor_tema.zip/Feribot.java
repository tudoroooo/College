import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
public class Feribot {
    public static void main(String[] args) {
        try
        {
        Scanner sc = new Scanner(new File ("feribot.in"));
        int n = sc.nextInt();
        int k = sc.nextInt(); 
         long [] g = new long[n]; 
        for (int i = 0; i < n; i++) {
            g[i] = sc.nextLong();
        }
        long ans=maxcost(g,k);
        try {
            FileWriter fw = new FileWriter("feribot.out");
            fw.write(Long.toString(ans));
            fw.close();

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        sc.close();
    } catch (FileNotFoundException e) {
        System.out.println(e.getMessage());
    }
}

        public static long maxcost(long[] g,int k)
        {
        long a = 0;
        long b = 10000000000000L;
        while (a < b) {
            long m = (a + b) / 2;
            if (check(g, k, m)) {
                b = m;
            } else {
                a = m + 1;
            }
        }
        return b;

    }
    public static boolean check(long[] g, int k, long C) {
        int i = 0;
        int j = 0;
        while (i < g.length) {
            long suma = 0;
            while (i < g.length && suma + g[i] <= C) {
                suma = g[i]+suma;
                i++;
            }
            j++;
            if ( suma == 0 || suma >C || j>k) {
                return false;
            }
        }
        return true;
    }
}
