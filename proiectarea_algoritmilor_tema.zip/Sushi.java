import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

class Sushi {
  // https://www.infoarena.ro/problema/rucsac
  static int n, m, x;
  static int[] prices; // prices[i] = price for i-th sushi plate
  static int[][] grades; // grades[i][j] = the grade that i-th friend gave to j-th plate

  Sushi() {}

  static int[] computeScorePerPlate() {
    int[] scorePerPlate = new int[m];

    for (int plate = 0; plate < m; ++plate) {
      scorePerPlate[plate] = 0;
      for (int friend = 0; friend < n; ++friend) {
        scorePerPlate[plate] += grades[friend][plate];
      }
    }

    return scorePerPlate;
  }

  static int task1() {
    int totalBudget = n * x;
    int[] scorePerPlate = computeScorePerPlate();
    
    /*
     * dp[i][j] = nota totala cea mai buna daca alegem din
     * primele i farfurii si avem de platit j in total
     */
    int[][] dp = new int[m][totalBudget + 1];

    for (int plate = 0; plate < m; ++plate) {
      for (int cost = 0; cost <= totalBudget; ++cost) {
        dp[plate][cost] = plate > 0 ? dp[plate - 1][cost] : 0;
        if (prices[plate] <= cost) {
          dp[plate][cost] = Math.max(
            dp[plate][cost],
            (plate > 0 ? dp[plate - 1][cost - prices[plate]] : 0) + scorePerPlate[plate]
          );
        }
      }
    }

    return dp[m - 1][totalBudget];
  }

  static int task2() {
    int totalBudget = n * x;
    int[] scorePerPlate = computeScorePerPlate();
    
    /*
     * dp[i][j] = nota totala cea mai buna daca alegem din
     * primele i farfurii si avem de platit j in total
     * si nu luam mai mult de 2 farfurii din fiecare
     */
    int[][] dp = new int[m][totalBudget + 1];

    for (int plate = 0; plate < m; ++plate) {
      for (int cost = 0; cost <= totalBudget; ++cost) {
        dp[plate][cost] = plate > 0 ? dp[plate - 1][cost] : 0;
        if (prices[plate] <= cost) {
          dp[plate][cost] = Math.max(
            dp[plate][cost],
            (plate > 0 ? dp[plate - 1][cost - prices[plate]] : 0) + scorePerPlate[plate]
          );
        }
        if (prices[plate] * 2 <= cost) {
          dp[plate][cost] = Math.max(
            dp[plate][cost],
            (plate > 0 ? dp[plate - 1][cost - prices[plate] * 2] : 0) + scorePerPlate[plate] * 2
          );
        }
      }
    }

    return dp[m - 1][totalBudget];
  }

  static int task3() {
    int totalBudget = n * x;
    int[] scorePerPlate = computeScorePerPlate();

    /*
     * dp[i][j][k] = profitul maxim pe care il putem obtine daca alegem
     * k platouri din primele i si avem de platit cel mult j
     */
    int[][][] dp = new int[m][totalBudget + 1][n + 1];
    
    for (int plate = 0; plate < m; ++plate) {
      for (int cost = 0; cost <= totalBudget; ++cost) {
        for (int no_plates = 1; no_plates <= n; ++no_plates) {
            
            dp[plate][cost][no_plates] = plate > 0 ? dp[plate - 1][cost][no_plates] : 0;
            
            if (prices[plate] <= cost) {
              dp[plate][cost][no_plates] = Math.max(
                dp[plate][cost][no_plates],
                (plate > 0 && no_plates > 0 ? dp[plate - 1][cost - prices[plate]][no_plates - 1] : 0)
                + scorePerPlate[plate]
              );
            }
            
            if (prices[plate] * 2 <= cost) {
              dp[plate][cost][no_plates] = Math.max(
                dp[plate][cost][no_plates],
                (plate > 0 && no_plates > 1 ? dp[plate - 1][cost - prices[plate] * 2][no_plates - 2] : 0)
                + scorePerPlate[plate] * 2
              );
            }
        }
      }
    }
    
    return dp[m - 1][totalBudget][n];
  }

  public static void main(String[] args) {
    try {
      Scanner sc = new Scanner(new File("sushi.in"));

      final int task = sc.nextInt(); // task number

      n = sc.nextInt(); // number of friends
      m = sc.nextInt(); // number of sushi types
      x = sc.nextInt(); // how much each of you is willing to spend

      prices = new int[m]; // prices of each sushi type
      grades = new int[n][m]; // the grades you and your friends gave to each sushi type

      // price of each sushi
      for (int i = 0; i < m; ++i) {
        prices[i] = sc.nextInt();
      }

      // each friends rankings of sushi types
      for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
          grades[i][j] = sc.nextInt();
        }
      }

      int ans;
      switch (task) {
      case 1:
        ans = Sushi.task1();
        break;
      case 2:
        ans = Sushi.task2();
        break;
      case 3:
        ans = Sushi.task3();
        break;
      default:
        ans = -1;
        System.out.println("wrong task number");
      }

      try {
        FileWriter fw = new FileWriter("sushi.out");
        fw.write(Integer.toString(ans) + '\n');
        fw.close();

      } catch (IOException e) {
        System.out.println(e.getMessage());
      }

      sc.close();
    } catch (FileNotFoundException e) {
      System.out.println(e.getMessage());
    }
  }
}

