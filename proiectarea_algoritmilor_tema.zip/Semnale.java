import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

class Semnale {

	static int sig_type, x, y;
	static final int mod = 1000000007;

	Semnale(){}
	
	static int compute_no_sequences(int one_combo) {
        /*
    	 * dp[i][j][k] = numarul de semnale de lungime i care se pot forma
    	 * folosind j biti de 1, avand k biti de 1 consecutivi pe ultimele pozitii
    	 */
    	 int[][][] dp = new int[x + y + 1][y + 1][one_combo + 1];
    	 dp[0][0][0] = 1;
    	 
    	 for (int i = 1; i <= x + y; ++i) {
    	     for (int j = 0; j <= y; ++j) {
    	         for (int k = 0; k <= one_combo; ++k) {
    	             if (k == 0) {
    	                 for (int l = 0; l <= one_combo; ++l) {
	                         dp[i][j][k] += dp[i - 1][j][l];
	                         dp[i][j][k] %= mod;
    	                 }
    	             } else if (1 <= j) {
	                     dp[i][j][k] += dp[i - 1][j - 1][k - 1];
	                     dp[i][j][k] %= mod;
    	             }
    	         }
    	     }
    	 }
    	 
    	 int sum = 0;
    	 for (int k = 0; k <= one_combo; ++k) {
    	     sum += dp[x + y][y][k];
    	     sum %= mod;
    	 }
    	 
    	 return sum;
	}

	static int type1() {
		return compute_no_sequences(1);
	}

	static int type2() {
		return compute_no_sequences(2);
	}

	public static void main(String[] args) {
		try {
			Scanner sc = new Scanner(new File("semnale.in"));

			sig_type = sc.nextInt();
			x = sc.nextInt();
			y = sc.nextInt();

			int ans;
			switch (sig_type) {
				case 1:
					ans = Semnale.type1();
					break;
				case 2:
					ans = Semnale.type2();
					break;
				default:
					ans = -1;
					System.out.println("wrong task number");
			}

			try {
				FileWriter fw = new FileWriter("semnale.out");
				fw.write(Integer.toString(ans));
				fw.close();

			} catch (IOException e) {
				System.out.println(e.getMessage());
			}

			sc.close();
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}
}

