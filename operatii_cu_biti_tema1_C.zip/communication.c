#include "communication.h"
#include "util_comm.h"
#include <stdio.h>
#include<string.h>


/* Task 1 - The Beginning */

void send_byte_message(void)
{
    uint8_t R,I,C,K;
    R='R'-'A'+1;
    send_squanch(R);
    I='I'-'A'+1;
    send_squanch(I);
    C='C'-'A'+1;
    send_squanch(C);
    K='K'-'A'+1;
    send_squanch(K);
}


void recv_byte_message(void)
{   uint8_t k;
    char C;
    for(int i=0;i<=4;i++)
    {k=recv_squanch();
        C='A'+k-1;
        fprintf(stdout,"%c",C);}
    
     
    /* TODO
     * Receive 5 encoded characters, decode them and print
     * them to the standard output (as characters)
     *
     * ATTENTION!: Use fprintf(stdout, ...)
     */
}


void comm_byte(void)
{
    uint8_t k;
    int i;
    for(i=0;i<=9;i++)
    {
        k=recv_squanch();
        send_squanch(k);
        send_squanch(k);
    }
    /* TODO
     * Receive 10 encoded characters and send each character (the character is
     * still encoded) 2 times
     */
}


/* Task 2 - Waiting for the Message */

void send_message(void)
{
    uint8_t res=0;
    char k;
    uint8_t i;
    uint8_t m;
    char s[100]="HELLOTHERE";
    uint8_t n= strlen(s);
    m=n;
    n=n<<2;
    send_squanch(n);
    for(i=0;i<m;i++)
    {k= (int)s[i]-64;
        send_squanch(k);
    }
    /* TODO
     * Send the message: HELLOTHERE
     * - send the encoded length
     * - send each character encoded
     */
}


void recv_message(void)
{
    uint8_t i;uint8_t k;uint8_t x;char C;
    k=recv_squanch();
    k=k<<2;
    k=k>>4;
    fprintf(stdout,"%d",k);
    for(i=0;i<k;i++)
    {
        x=recv_squanch();
        C='A'+x-1;
        fprintf(stdout,"%c",C);
    }
    /* TODO
     * Receive a message:
     * - the first value is the encoded length
     * - length x encoded characters
     * - print each decoded character
     * 
     * ATTENTION!: Use fprintf(stdout, ...)
     */
}


void comm_message(void)
{
    uint8_t i,n=0,k;
    int m;
    uint8_t x;
    n=recv_squanch(); /*primim lungimea codificata pe care o decodificam */
    n=n<<2;
    n=n>>4;
    int s[100];
    for(i=0;i<n;i++)
    s[i]=recv_squanch(); /*preluam mesajul intr-un vector */
     if(s[n-1]==16)
        { char v2[]="PICKLERICK";
            m=strlen("PICKLERICK");
            k=m;
            m=m<<2;
            send_squanch(m);
            for(i=0;i<k;i++)
            {
                x=(int)v2[i] - 64;
                send_squanch(x);
            }
        }
        else
        {
            char v1[]="VINDICATORS";
            m=strlen(v1);
            k=m;
            m=m<<2;
            send_squanch(m);
            for(i=0;i<k;i++)
            {
                x=(int)v1[i]-64;
                send_squanch(x);
            }
        }
              
            
            
            
        
            
        /* TODO
         * Receive a message from Rick and do one of the following depending on the
         * last character from the message:
         * - 'P' - send back PICKLERICK
         * - anything else - send back VINDICATORS
         * You need to send the messages as you did at the previous tasks:
         * - encode the length and send it
         * - encode each character and send them
         */
    }



/* Task 3 - In the Zone */

void send_squanch2(uint8_t c1, uint8_t c2)
{
    uint8_t i,k=0,x=0;
    for(i=0;i<=3;i++)
    {
        if((c2 & (1<<i))!=0)
            k=(k|(1<<x));
        x++;
        if((c1 & (1<<i))!=0)
            k=(k|(1<<x));
        x++;
    }
    send_squanch(k);
      
    /* TODO
     * Steps:
     * - "merge" the character encoded in c1 and the character encoded in c2
     * - use send_squanch to send the newly formed byte
     */
}


uint8_t decode_squanch2(uint8_t c)
{
    /*
     * Decode the given byte:
     * - split the two characters as in the image from ocw.cs.pub.ro
     */

    uint8_t res = 0;
    uint8_t i,x=0;
    for(i=0;i<=6;i=i+2)
    {
        if((c&(1<<i))!=0)
            res|=(1<<x);
        if((c&(1<<(i+1)))!=0)
            res|=(1<<(x+4));
        x++;
            
    }
    

    

    return res;
}
