#include "gates.h"

#include <stdio.h>
#include <assert.h>

/* Task 1 - Bit by Bit */

uint8_t get_bit(uint64_t nr, uint8_t i)
{
    assert(i <= 8 * sizeof nr);

    uint8_t res = -1;

    uint64_t mask= (uint64_t)1<<i;
    res=(mask & nr) !=0;
    return res;
    
}


uint64_t flip_bit(uint64_t nr, uint8_t i)
{
    assert(i <= 8 * sizeof nr);

    uint64_t res = -1;
    uint64_t mask= (uint64_t)1<<i;
    if (get_bit( nr, i) ==0)
        res = nr | mask ;
    else
    { mask= ~ ((uint64_t)1<<i);
      res= nr & mask;}
    return res;

    
}


uint64_t activate_bit(uint64_t nr, uint8_t i)
{
    assert(i <= 8 * sizeof nr);

    uint64_t res = 0xFF;
    uint64_t mask= (uint64_t) 1<<i;
    res = nr | mask;
    return res;
}


uint64_t clear_bit(uint64_t nr, uint8_t i)
{
    assert(i <= 8 * sizeof nr);

    uint64_t res = -1;

    uint64_t mask = ~((uint64_t)1<<i);
    res= nr & mask;
    return res;
}


/* Task 2 - One Gate to Rule Them All */

uint8_t nand_gate(uint8_t a, uint8_t b)
{
    assert (a == 0 || a == 1);
    assert (b == 0 || b == 1);

    return !(a & b);
}


uint8_t and_gate(uint8_t a, uint8_t b)
{
    assert (a == 0 || a == 1);
    assert (b == 0 || b == 1);

    uint8_t res = -1;

    res=!(nand_gate(a,b));

    return res;
}


uint8_t not_gate(uint8_t a)
{
    assert (a == 0 || a == 1);

    uint8_t res = -1;

    res=nand_gate(a,1);

    return res;
}


uint8_t or_gate(uint8_t a, uint8_t b)
{
    assert (a == 0 || a == 1);
    assert (b == 0 || b == 1);

    uint8_t res = -1;
    uint8_t k=not_gate(a);
    uint8_t x=not_gate(b);
    res=nand_gate(k,x);

    return res;
}


uint8_t xor_gate(uint8_t a, uint8_t b)
{
    assert (a == 0 || a == 1);
    assert (b == 0 || b == 1);

    uint8_t res = -1;

    if(and_gate(a,b)==0 && or_gate(a,b)==1)
        res=1;
    else
        res=0;

    return res;
}


/* Task 3 - Just Carry the Bit */

uint8_t full_adder(uint8_t a, uint8_t b, uint8_t c)
{
    assert (a == 0 || a == 1);
    assert (b == 0 || b == 1);
    assert (c == 0 || c == 1);

    uint8_t res = 0;
    uint8_t sum,carry,k,z,y;
    k=xor_gate(a,b);
    sum=xor_gate(k,c);
    z=and_gate(a,b);
    y=and_gate(c,k);
    carry=or_gate(z,y);
    if(carry==1)
        res |= ((uint64_t)1<<0);
    if(sum==1)
        res |= ((uint64_t)1<<1);
        
    return res;
}


uint64_t ripple_carry_adder(uint64_t a, uint64_t b)
{
    uint64_t res = 0;
    uint64_t ai,bi,c=0,i;
    uint64_t m,n;
    for(i=0;i<=63;i++)
    {
        ai=get_bit(a,i);
        bi=get_bit(b,i);
        m=full_adder(ai,bi,c);
        n=full_adder(ai,bi,c);
        if( get_bit(m,1) !=0) /*verificam daca suma bitilor e diferita de 0*/
            res |= ((uint64_t)1<<i);
        if(get_bit(n,0) ==0) /*verificam valoarea lui carry */
            c=0;
        else
            c=1;
        
        
    }
     if(c==1)
         res=0;
    

    return res;
}
