Gates :
   Task 1:
  Functia get_bit returneaza cu ajutorul unei masti  valoarea bitului i dintr-un numar.
  Mai departe,ne folosim de functia get_bit pentru a inversa bitul i dintr-un numar. ( Daca bitul este 0,acesta va deveni 1 si invers)
  Ultimele doua functii din primul task schimba valoarea bitului i in 1 si respectiv 0, cu ajutorul unei masti.

  Task 2:
   Functia and_gate returneaza valoarea negata a lui nand_gate. Functia not_gate se foloseste de nand_gate dintre bitul a si 1 pentru a nega valoarea bitului a.
   La functia or_gate negam valoarea bitilor a si b, iar apoi facem nand intre valorile astfel obtinute. Functia xor are valoarea 1 doar daca bitii a si b
sunt diferiti ,deci daca a&b face 0, iar a|b face 1.

  Task 3:
  Suma si carry se afla cu ajutorul functiilor de la taskul 2. Functia full_adder returneaza un numar in care bitul 0 reprezinta carry-ul ,iar bitul 1 suma
celor trei biti trimisi ca parametrii.
  Functia ripple_carry_adder returneaza suma a doua numere luandu-se pe rand bit cu bit. Daca suma este un numar ce nu poate fi reprezentat pe 63 de biti,
adica daca carry-ul are valoarea 1 la final,atunci functia returneaza 0.

Communications :
   La primul task, ne folosim de codul Ascii pentru a codifica/decodifica mesajul.
  La taskul 2 lungimea se codifica shiftand la stanga de 2 ori si se decodifica shiftand numarul primit la stanga de 2 ori, iar apoi la dreapta de 4 ori.
Codificarea/decodificarea mesajului se face ca la primul task.
  Taskul 3:
    send_squanch 2: variabilele k si x sunt initializate cu 0  .Valoarea lui x creste cu 1 dupa verificarea bitului i din c2 si inca o data dupa verificarea
bitului i din c1. Daca bitul i din c1 sau c2 este activ,atunci bitul x din k va deveni 1.
   decode_squanch : Se initializeaza res si x cu 0. Se parcurg bitii lui c din 2 in 2 cu ajutorul unei instructiuni for. Daca bitul i din c  are valoarea 1, atunci
bitul x din res va fi activat. Daca bitul i+1 are valoarea 1, atunci bitul x+4 din res va fi activat.

 Hunt :
   Task 1 - Se foloseste o variabila k care creste cu o unitate atunci cand gasim un bit activ si devine 0 cand gasim un bit nul.
   Task 2 - Se verifica daca numarul de biti activi(k) din enemy este par sau impar si se creeaza numarul res pe baza ecuatiilor specifice .
   Task 3 - Se observa ca atunci cand bitul i din cocktail este 1, bitul i din antibodies_high,adica bitul (i+17) din res trebuie sa fie tot 1.
            Variabila k reprezinta numarul de biti egali cu 1. Variabila x este initializata cu 1 si devine 0 atunci cand gasim un bit activ intre 2 biti nuli
            sau cand gasim 5 biti consecutivi de 1, deci cand padurea nu este de tipul 0.
            Intr-un vector adaugam pe prima pozitie primul bit activ (v[0]), si pe a doua pozitie pe cel de-al doilea bit activ (v[1]). Functia returneaza diferenta dintre
            v[1] si v[0]. 
