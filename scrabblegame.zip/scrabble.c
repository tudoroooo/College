#include"util/print_board.h"
#include"util/scrabble.h"
#include<stdio.h>
#include<string.h>
#include<math.h>
char a[15][15];
char aux[15][15];
int nr_randuri(char str[10])
{
    int len,Ni;
    len=strlen(str);
    Ni=(int)str[0]-48;
    if(len>1)
        Ni=((int)str[0]-48)*10+((int)str[1]-48);
    return Ni;

}
void task0()
{
    int i,j;
    for(i=0;i<15;i++)
        for(j=0;j<15;j++)
    a[i][j]='.';
}
void task1(char word[100])
{
    int x,y,d,j;
    int m,q=0,p=0;
    m=strlen(word)-6;
    if(word[1]!=' ')
    { q=1;
      if(word[4]!=' ')
         p=1;}
    if(word[1]==' ')
        if(word[3]!=' ')
            p=1;
    y=word[0]-'0';
    x=word[2]-'0';
    d=word[4]-'0';
    if(q==0 && p==1)
    {x=x*10+(word[3]-'0');
        d=word[5]-'0';
        m=m-1;
    }
    if(q==1 && p==0)
    {
        y=y*10+(word[1]-'0');
        d=word[5]-'0';
        x=word[3]-'0';
        m=m-1;
    }
    if(p==1 && q==1)
    {
        y=y*10+(word[1]-'0');
        x=word[3]-'0';
        x=x*10+(word[4]-'0');
        d=word[6]-'0';
        m=m-2;
    }
    if(d==0)
        for(j=0;j<m;j++)
         a[y][x+j]=word[j+6+p+q];
    if(d==1)
        for(j=0;j<m;j++)
          a[y+j][x]=word[j+6+p+q];
    
}

int task2(char *str,int m,int vect[])
{
    int i,punct=0,p=0,q=0,x;
    if(*(str+1)!=' ')
    { q=1;
      if(*(str+4)!=' ')
         p=1;}
    if(*(str+1)==' ')
        if(*(str+3)!=' ')
            p=1;
    for(i=(6+p+q);i<m;i++)
    {
        x=*(str+i)-'A';
        punct=vect[x]+punct;
    }
    return punct;
    
}
int punctaj_cuvant(char str[100],int m,int vect[])
{
    int i,x,punct=0;
    for(i=0;i<m;i++)
    {
        x=str[i]-'A';
        punct=vect[x]+punct;
    }
    return punct;
    
}
int f(char str[10],char word[100])
{
    int i,j,bonus=0;
    task1(word);
    if(strstr(word,str)!=NULL)
    {
        for(i=0;i<15;i++)
        {for(j=0;j<15;j++)
            { if(a[i][j]!='.' && (int)bonus_board[i][j]==1)
        {
            
             bonus=bonus+1;
        }
        }
        }
        
    }
    return pow(2,bonus);
}
int g(char str[10],char word[100])
{
    int n,lun,i,j,bonus=0,c=1;
    task1(word);
    n=strlen(str);
    lun=strlen(word);
    for(i=2;i>0;i--)
    if(word[lun-i]!=str[n-i])
        c=0;
    if(c==1)
    {
        for(i=0;i<15;i++)
        {for(j=0;j<15;j++)
            {if(a[i][j]!='.' && (int)bonus_board[i][j]==2)
              {
                    bonus=bonus+1;
              }
        }
    }
    }
    return pow(3,bonus);
        
}
int good_word(int x,char play[][100])
{
    int i,j,k,m,check=0,oriz,vert;
    for(i=0;i<15;i++)
    for(j=0;j<15;j++)
    {
        if (a[i][j]==play[x][0])
        {   oriz=1;
            vert=1;
            m=strlen(play[x]);
            for(k=j+1;k<j+m;k++)
        {
            if(a[i][k]!='.' || k>14)
                oriz=0;
        }
        for(k=i+1;k<i+m;k++)
        {
            if(a[k][j]!='.' || k>14)
                vert=0;
        }
        if(oriz!=0 || vert!=0)
            check=1;
        }
    }
    return check;
}

void aranjare(int x,char play[][100])
    {
        int i,j,oriz,vert,k,d=0,m,contor=0;
    for(i=0;i<15;i++)
        {for(j=0;j<15;j++)
          {
        if (a[i][j]==play[x][0])
        {   oriz=1;
            vert=1;
            m=strlen(play[x]);
            for(k=j+1;k<j+m;k++)
        {
            if(a[i][k]!='.' || k>14)
                oriz=0;
        }
        for(k=i+1;k<i+m;k++)
        {
            if(a[k][j]!='.' || k>14)
                vert=0;
        }
      if(oriz==1 && contor==0)
      {  for(k=j;k<j+m;k++)
             a[i][k]=play[x][d++];
              contor++;}
        if(oriz==0 && vert==1 && contor==0)
        { for(k=i;k<i+m;k++)
            a[k][j]=play[x][d++];
            contor++;}
        }
    
        }
        }
        
    }
int bonus1(char str[10],int x,char play[][100])
{
    int i,j,bonus=0,m,contor=0,k,oriz,vert,d=0,max=0;
    if(strstr(play[x],str)!=NULL)
    {
        for(i=0;i<15;i++)
            {for(j=0;j<15;j++)
              {
            if (a[i][j]==play[x][0])
            {   oriz=1;
                vert=1;
                m=strlen(play[x]);
                for(k=j+1;k<j+m;k++)
            {
                if(a[i][k]!='.' || k>14)
                    oriz=0;
            }
            for(k=i+1;k<i+m;k++)
            {
                if(a[k][j]!='.' || k>14)
                    vert=0;
            }
          if(oriz==1)
          {  for(k=j;k<j+m;k++)
              {aux[i][k]=play[x][d++];
               if((int)bonus_board[i][k]==1)
                   bonus++;}
              }
            if(oriz==0 && vert==1)
            { for(k=i;k<i+m;k++)
                {aux[k][j]=play[x][d++];
                if((int)bonus_board[k][j]==1)
                    bonus++;}
            }
                }
        
            }
            }
        
    }
    return pow(2,bonus);
}
int bonus2(char str[10],int x,char play[][100])
{
    int n,lun,i,j,bonus=0,c=1,oriz,vert,k,contor=0,d=0,max=0;
    n=strlen(str);
    lun=strlen(play[x]);
    for(i=2;i>0;i--)
        if(play[x][lun-i]!=str[n-i])
            c=0;
    if(c==1)
        {
         for(i=0;i<15;i++)
                {for(j=0;j<15;j++)
                  {
                if (a[i][j]==play[x][0])
                {   oriz=1;
                    vert=1;
                    for(k=j+1;k<j+lun;k++)
                {
                    if(a[i][k]!='.' || k>14)
                        oriz=0;
                }
                for(k=i+1;k<i+lun;k++)
                {
                    if(a[k][j]!='.' || k>14)
                        vert=0;
                }
              if(oriz==1)
              {  for(k=j;k<j+lun;k++)
                  {aux[i][k]=play[x][d++];
                      if((int)bonus_board[i][k]==2)
                          bonus++;}
              }
                  
                      
                if(oriz==0 && vert==1)
                { for(k=i;k<i+lun;k++)
                    {aux[k][j]=play[x][d++];
                    if((int)bonus_board[i][k]==2)
                        bonus++;}
                }
        }
                  }
                }
        }
    return pow(3,bonus);
            
    }
void aux_matrix()
{
    int i,j;
    for(i=0;i<15;i++)
    for(j=0;j<15;j++)
    aux[i][j]=a[i][j];
}

int main()
{
    char word[100];
    char nr[10];
    int i,j,p1=0,p2=0;
    int p1f=0,p2f=0;
    char n;
    char s1[10];
    char s2[10];
    n=fgetc(stdin);
    getchar();
    task0();
    if(n=='0')
        print_board(a);
    if(n=='1')
    {
        gets(nr);
        for(i=0;i<nr_randuri(nr);i++)
    {
        gets(word);
        task1(word);
    }
        print_board(a);
    }
    if(n=='2')
    {
        int vect[]={1,3,3,2,1,4,2,4,1,8,5,1,3,1,1,3,10,1,1,1,1,4,4,8,4,10};
        int m;
        gets(nr);
        for(i=0;i<nr_randuri(nr);i++)
    {
        gets(word);
        m=strlen(word);
         if(i%2==0)
            p1=p1+task2(word,m,vect);
        if(i%2==1)
            p2=p2+task2(word,m,vect);
    }
        printf("Player 1: ");
        printf("%d Points", p1);
        printf("\n");
        printf("Player 2: ");
        printf("%d Points\n", p2);
        
        
    }
    if(n=='3')
    {
        int vect[]={1,3,3,2,1,4,2,4,1,8,5,1,3,1,1,3,10,1,1,1,1,4,4,8,4,10};
        int m;
        gets(s1);
        gets(s2);
        gets(nr);
        for(i=0;i<nr_randuri(nr);i++)
        {
            gets(word);
            task0(word);
            m=strlen(word);
            if(i%2==0)
            {   p1=task2(word,m,vect);
                p1f=f(s1,word)*g(s2,word)*p1+p1f;}
            if(i%2==1)
            { p2=task2(word,m,vect);
                p2f=f(s1,word)*g(s2,word)*p2+p2f;}
        }
        printf("Player 1: ");
        printf("%d Points", p1f);
        printf("\n");
        printf("Player 2: ");
        printf("%d Points\n", p2f);
    }
    if(n=='4')
    {
        gets(s1);
        gets(s2);
        gets(nr);
        int good[100];
        for(i=0;i<100;i++)
          good[i]=1;
        for(i=0;i<nr_randuri(nr);i++)
        {
            gets(word);
            task1(word);
            for(j=0;j<100;j++)
            if(strstr(word,words[j])!=NULL)
                good[j]=0;
        }
        for(i=0;i<100;i++)
            if(good_word(i,words) && good[i])
            {aranjare(i,words);
                break;
            }
                
                
                
        print_board(a);
        
    }
    if(n=='5')
    {
        gets(s1);
        gets(s2);
        gets(nr);
        int good[100];
        int p[100];
        int vect[]={1,3,3,2,1,4,2,4,1,8,5,1,3,1,1,3,10,1,1,1,1,4,4,8,4,10};
        int m;
        int x=0;
        int max;
        for(i=0;i<100;i++)
           p[i]=0;
        for(i=0;i<100;i++)
          good[i]=1;
        for(i=0;i<nr_randuri(nr);i++)
        {
            gets(word);
            task1(word);
            m=strlen(word);
            for(j=0;j<100;j++)
            if(strstr(word,words[j])!=NULL)
                good[j]=0;
            if(i%2==0)
            {   p1=task2(word,m,vect);
                p1f=f(s1,word)*g(s2,word)*p1+p1f;}
            if(i%2==1)
            { p2=task2(word,m,vect);
                p2f=f(s1,word)*g(s2,word)*p2+p2f;}
        }
        for(i=0;i<100;i++)
                if(good_word(i,words) && good[i])
                {
                    aux_matrix();
                    int punctaj=0;
                    m=strlen(words[i]);
                    punctaj=punctaj_cuvant(words[i],m,vect);
                    p[i]=punctaj*bonus1(s1,i,words);
                    aux_matrix();
                    p[i]=p[i]*bonus2(s2,i,words);
                    
                }
        max=p[0];
        for(i=1;i<100;i++)
          if(p[i]>max)
          {
              max=p[i];
              x=i;
          }
        if(p2f+max>=p1f)
        { aranjare(x,words);
            print_board(a);}
        else
            printf("Fail!\n");
        }
    if(n=='6')
    {
        gets(s1);
        gets(s2);
        gets(nr);
        int good[100];
        int p[100];
        int vect[]={1,3,3,2,1,4,2,4,1,8,5,1,3,1,1,3,10,1,1,1,1,4,4,8,4,10};
        int m;
        int x=0;
        int max;
        int v;
        for(i=0;i<100;i++)
           p[i]=0;
        for(i=0;i<100;i++)
          good[i]=1;
        for(i=0;i<nr_randuri(nr);i++)
        {
            gets(word);
            task1(word);
            m=strlen(word);
            for(j=0;j<100;j++)
            if(strstr(word,words[j])!=NULL)
                good[j]=0;
            p1=task2(word,m,vect);
            p1f=f(s1,word)*g(s2,word)*p1+p1f;
            for(v=0;v<100;v++)
                    if(good_word(v,words) && good[v])
                    {
                        aux_matrix();
                        int punctaj=0;
                        m=strlen(words[v]);
                        punctaj=punctaj_cuvant(words[v],m,vect);
                        p[v]=punctaj*bonus1(s1,v,words);
                        aux_matrix();
                        p[v]=p[v]*bonus2(s2,v,words);
                        
                    }
            max=p[0];
            for(v=1;v<100;v++)
              if(p[v]>max)
              {
                  max=p[v];
                  x=v;
              }
            p2f=p2f+max;
            aranjare(x,words);
            }
        print_board(a);
        if(p1f>p2f)
            printf("Player %d Won!\n", 1);
            else
                   printf("Player %d Won!\n", 2);
}
}
